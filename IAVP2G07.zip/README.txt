//Esta explicacion se encuentra también en la primera sección de la memoria

Autores: Diego Baratto Valdivia, Juan Barea Gallego

Descripción para el Usuario (IMPORTANTE): se expondrán los controles y diferentes acciones que puede realizar el jugador, así como el desarrollo 
de una partida.

Al ejecutar el juego, se mostrará el tablero y la disposición de los diferentes sospechosos y los jugadores que componen la partida. 
Las reglas del juego son sencillas y se expondrán en párrafos siguientes.

El primer turno le corresponde al usuario, el siguiente a SmartBot y el último le corresponde a DumbBot. Dichos turnos se repetirán de 
manera cíclica hasta que acabe la partida o un personaje sea eliminado, en cuyo caso se saltará el turno de dicho jugador.

Las acciones que puede realizar un jugador son las siguientes: moverse a una casilla libre (haciendo click sobre ella) o llamar a un sospechoso 
(haciendo click sobre el sospechoso en cuestión). Solo se puede realizar una de ambas acciones. Tras hacer dicho paso, podrá lanzar una 
pregunta si la situación es correcta, es decir, si hay sospechosos con el jugador (si no hay sospechosos, cambia el turno). 
Para el usuario, preguntar es sencillo. Se dispone de dos botones en la parte inferior izquierda de la pantalla, si son pulsados, 
mostrará los sospechosos que se encuentran en la sala y todas las armas. Se muestran con un parpadeo aquellas cartas de las cuales se 
desconocen datos. Una vez el usuario haya seleccionado dos opciones válidas, podrá realizar la sugerencia (la tercera opción es la sala en la 
que se encuentra actualmente, como se especifica en el enunciado). Para ello, se mostrará un botón en la parte inferior derecha, Suggest. 
Se pueden dar dos opciones: otro jugador puede responder con una carta que tiene en su baraja, en cuyo caso se mostrará el texto, 
se marcará en la tabla automáticamente y se pasará turno, y que ningún jugador pueda responder, en cuyo caso el botón Suggest cambiará a 
Accuse y podrá realizar la acusación, teniendo en cuenta que si no es la correcta, el usuario quedará eliminado de la partida (se mostrará un 
diálogo de confirmación para realizar la acusación). Si se encuentra en una sala con sospechosos, podrá directamente hacer una sugerencia sin 
realizar el primer paso.
	
Una vez el turno del usuario haya terminado, se pasará al turno de ambos bots. Se mostrará feedback al usuario de qué cartas han sido mostradas
para facilitar la etapa de testing del juego. El usuario dispone también de un botón en la parte superior izquierda (o tecla T) 
para mostrar la tabla o base de conocimiento de la partida. En principio solo dispone de su base de conocimiento, pero existe la opción de, 
en la propia tabla, pulsar sobre la opción Spy para tener acceso al conocimiento de todos los jugadores restantes.

Existe también las opciones de resetear el juego a un estado inicial (posición de las salas, jugadores, base del conocimiento, por ejemplo) y 
de cerrar la aplicación. Sendos botones se encontrarán en la parte superior derecha de la pantalla. Si son pulsados, se mostrará un diálogo 
de confirmación para asegurar que no se pulsan por accidente.